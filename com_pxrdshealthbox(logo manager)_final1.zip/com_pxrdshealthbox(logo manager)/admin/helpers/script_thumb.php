<form action="" method="post" name="adminForm" id="adminForm" class="form-validate" enctype="multipart/form-data">
	<?php
	
	$logos = scandir(JPATH_SAVED_LOGOS);
	$thumbs  = scandir(JPATH_SAVED_LOGOS.'/thumb');
	foreach ($logos as $indx => $logo) 
	{
		if(is_dir(JPATH_SAVED_LOGOS."/$logo"))
		{
			unset($logos[$indx]);
		}
	}

	foreach ($thumbs as $indx => $thumb) 
	{
		if(is_dir(JPATH_SAVED_LOGOS."/$thumb"))
		{
			unset($thumbs[$indx]);
		}
	}

	$diff_key = array_keys(array_diff($logos, $thumbs));
	$msg = '';
	if($diff_key)
	{
		require_once(JPATH_HELPERS.'/resize-class.php');
		$cnt = 0;
		foreach ($diff_key as $idx => $key ) 
		{
			$file_name = $logos[$key];
			$resizeClass = new resize(JPATH_SAVED_LOGOS."/$file_name");
			$resizeClass->resizeImage(100,100,'auto');
			$r = $resizeClass->saveImage(JPATH_SAVED_LOGOS."/thumb/$file_name");

			if($r)
			{
				$msg .= '<p><b> '. JPATH_SAVED_LOGOS."/thumb/$file_name" .' </b></p>';
				$cnt++;
			}

		}
	}
		
	echo '<h3 style="color:red"><b> Process '. $cnt .'/'. count($diff_key) .' images successfully!</b></h3>';
	echo $msg;
	?>
	<input type="hidden" name="task" value=''>
	<input type="hidden" name="controller" value='org'>
	<input type="hidden" name="option" value='com_pxrdshealthbox'>
	<?php echo JHtml::_('form.token'); ?>
</form>	