DROP TABLE IF EXISTS `#__xrds_portals`;


