<?php
defined('_JEXEC') or die;
class PxrdshealthboxModelOrg extends JModelAdmin
{
	protected $text_prefix = 'COM_PXRDSHEALTHBOX';

	public function getTable($type = 'Pxrdshealthbox', $prefix = 'PxrdshealthboxTable', $config = array())	
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	public function getForm($data = array(), $loadData = true)
	{
		$app = JFactory::getApplication();
		$form = $this->loadForm('com_pxrdshealthbox.org', 'org', 
									array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form))
		{
		return false;
		}
		return $form;
	}

	protected function loadFormData()
	{
		$data = JFactory::getApplication()->getUserState('com_pxrdshealthbox.edit.org.data', array());

		if (empty($data))
		{
		$data = $this->getItem();
		}

		return $data;
	}
	
	protected function prepareTable($table)
	{
		$table->name = htmlspecialchars_decode($table->name, ENT_QUOTES);		
	}


	public function save()
	{
		$input = JFactory::getApplication()->input;
        $task = $input->post->get('task');
        $data = $input->post->get('jform', array(), 'array');	
        
        //**Get Logo
        $logo = JRequest::getVar('logo',null,'files');	        
    	$file_name = time().'_'.preg_replace('/[^a-zA-Z0-9\_\-\.]/', '', $logo['name']);
    	$des_path = JPATH_ROOT.DIRECTORY_SEPARATOR.'components/com_pxrdshealthbox/images/logos/'.$file_name;
    	$tmp_path = $logo['tmp_name'];

    	if(move_uploaded_file($tmp_path,$des_path))
    	{
    		$data['logo'] = $file_name;
    	}   
    	else
    	{
    		unset($data['logo'] );
    		
    	}	

    	//**Save all data
    	parent::save($data);
    	$id = $data['id'] ? $data['id'] : $this->_db->insertid();
		$msg = 'Saved';

    	if($task=='org.apply')
    	{
    		JFactory::getApplication()->redirect('index.php?option=com_pxrdshealthbox&view=org&id='.$id, false);
    	}
    	if($task=='org.save')
    	{
    		JFactory::getApplication()->redirect('index.php?option=com_pxrdshealthbox',false);
    	}

	}

	public function delete()
	{
		$input = JFactory::getApplication()->input;
		$cid = $input->post->get('cid', array(), 'array');		
	
		$ids = implode(',', $cid);

		$sql = "SELECT logo FROM #__xrds_portals WHERE id IN ($ids)";

		$this->_db->setQuery($sql);

		$logos = $this->_db->loadObjectList();

		if(parent::delete($cid))
		{	
			foreach ($logos as $logo) 
			{
				$path = JPATH_SITE.'/components/com_pxrdshealthbox/images/logos/'.$logo->logo;				
				unlink($path);
			}

		}
		JFactory::getApplication()->redirect('index.php?option=com_pxrdshealthbox',false);
	}



}