<?php
defined('_JEXEC') or die;

class PxrdshealthboxControllerOrg extends JControllerForm
{

	public function save()
	{
		$model = $this->getModel('org');
		$model->save();		
	}
	public function delete()
	{
		$model = $this->getModel('org');
		$model->delete();		
	}

}